rforcats
=======

Inspired by [jsforcats.com](http://jsforcats.com/) - __rforcats__ is aimed at teaching cats R programming.

### people

* Scott Chamberlain [@sckott](https://github.com/sckott)
* Carson Sievert [@cpsievert](https://github.com/cpsievert)
* Ben Marwick [@benmarwick](https://github.com/benmarwick)
* Noam Ross [@noamross](https://github.com/noamross)
* You?

### cats

* the orange one at the bottom of the page: _Leo_ (aka _boom boom_, _muffin_, _goose_, _goosie_, _bumpkin_, _goosebump_, _kitten face_, _kitten butt_, or _monkey_)

### license

CC0
