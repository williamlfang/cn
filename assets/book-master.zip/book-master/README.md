book
====

[![Build Status](https://travis-ci.org/openingscience/book.png?branch=master)](https://travis-ci.org/openingscience/book)

The Book (cf. http://www.openingscience.org/)